# Importing all the necessary packages
import configparser
import os
import pandas as pd
import numpy as np

class RetrieveData:
    def __init__(self, ini_file_name):
        """
        Initialize the class with configuration file name
        """

        
        # config.ini file name
        self.ini_file_name              = ini_file_name

        # Loading the configuration file
        self.config                     = configparser.ConfigParser()
        self.config.read(self.ini_file_name)

        # Number of components
        self.num_components             = int(self.config['COMPONENTS']['num_components'])

        # Total time for the time series
        self.total_time                 = int(self.config['COMPONENTS']['total_time'])

        # Global learning rate
        self.global_learning_rate       = float(eval(self.config['GLOBAL_PARAMETERS']['gamma_g']))

        # Global regularization rate
        self.global_regularization_rate = float(eval(self.config['GLOBAL_PARAMETERS']['lambda_g']))

        # # Proportion of training data
        self.training_prop              = float(eval(self.config['TRAINING']['train_set_prop']))

        # Training time
        # self.training_time              = int(np.ceil(self.training_prop * self.total_time))
        self.training_time          = 200

        # Validation time
        self.validation_time            = 1000

        # Initializing data from each component
        self.local_learners_pack        = None

        # Initializing diagonal matrix data for the global learner
        self.global_learners_pack       = None

        # Initializing data for the HMatrix
        self.HMatrix_pack               = None

        # Validation pack
        self.validation_pack            = None

        # Initializing vector that stores size of states in each component
        self.comp_size_vec              = None

        # Size of the global state vector
        self.global_state_size          = None

        # Output size vector 
        self.output_size_vec            = None

        # Global output size
        self.global_output_size         = None

        # Output data location 
        self.results_location            = self.config['LOCATION']['results_location']

        # Validation results location 
        self.valid_location             = self.config['LOCATION']['valid_location']

        # Centralized Kalman Filter pack
        self.CKF_pack                   = None

        # Global Y
        self.global_Y                   = None

        # Global Y valid   
        self.global_Y_valid             = None

        # Output start indices
        self.output_start_vec                = np.zeros((self.num_components, 1), dtype = int)
        # Preparing the data
        self.PrepareData()


    def PrepareData(self):
        """
        Get the data for each component.
        
        Outputs:
        - M: Number of components
        - T: Length of time series data
        - components: A nested dictionary containing properties of all components and the corresponding observation time series
        """

        try:
            # Getting the data folder location from config file
            data_location           = self.config['LOCATION']['data_location']
            valid_data_location     = self.config['LOCATION']['valid_data_location']

            # Getting the learning rate of local loss
            eta_l_str       = self.config['LOCAL_PARAMETERS']['eta_l']
            eta_l           = [float(x) for x in eta_l_str.split(',')]

            # Getting the learning rate of global loss for each component
            eta_g_str       = self.config['LOCAL_PARAMETERS']['eta_g']
            eta_g           = [float(x) for x in eta_g_str.split(',')]

            # Getting the local regularization parameter
            lambda_l_str    = self.config['LOCAL_PARAMETERS']['lambda_l']
            lambda_l        = [float(x) for x in lambda_l_str.split(',')]

            # Raising an exception if the learning rate and regularization parameter vectors are not the correct size
            if len(eta_l) != self.num_components or len(lambda_l) != self.num_components or len(eta_g) != self.num_components:
                raise ValueError(f"Length of eta_l vector (= {len(eta_l)}) and/or length of lambda_l vector (= {len(lambda_l)}) \
                                 and/or length of eta_g vector (= {len(eta_g)}) != number of components (= {self.num_components})")

            # Dictionary to store all component data and global learner package
            self.local_learners_pack    = {}
            self.global_learners_pack   = {}
            self.HMatrix_pack           = {}
            self.CKF_pack               = {}
            self.validation_pack        = {}
            self.global_Y               = {}
            self.global_Y_valid         = {}
            A_mm                        = {}
            # Initializing total size of state vector
            self.comp_size_vec          = np.zeros((self.num_components, 1), dtype = int)
            self.global_state_size      = 0

            self.output_size_vec        = np.zeros((self.num_components, 1), dtype = int)
            self.global_output_size     = 0

            # A_complete_path             = os.path.join(data_location, 'A_complete.csv')
            # C_complete_path             = os.path.join(data_location, 'C_complete.csv')
            # df_A_complete               = pd.read_csv(A_complete_path, header = None)
            # df_C_complete               = pd.read_csv(C_complete_path, header = None)
            # A_comlete                   = df_A_complete.to_numpy()
            # C_complete                  = df_C_complete.to_numpy()
            
            # A_complete_valid_path       = os.path.join(valid_data_location, 'A_complete.csv')
            # df_A_complete_valid         = pd.read_csv(A_complete_valid_path, header = None)
            # A_complete_valid            = df_A_complete_valid.to_numpy()

            for m in range(self.num_components):
                A_matrix_path = os.path.join(data_location, f'C{m+1}/A.csv')
                C_matrix_path = os.path.join(data_location, f'C{m+1}/C.csv')
                Q_train_matrix_path   = os.path.join(data_location, f'C{m+1}/Q.csv')
                R_train_matrix_path   = os.path.join(data_location, f'C{m+1}/R.csv')


                Y_path = os.path.join(data_location, f'C{m+1}/y.csv')
                df_A = pd.read_csv(A_matrix_path, header=None)
                df_C = pd.read_csv(C_matrix_path, header=None)
                df_Y = pd.read_csv(Y_path, header=None)
                df_Q_train      = pd.read_csv(Q_train_matrix_path, header = None)
                df_R_train      = pd.read_csv(R_train_matrix_path, header = None)
                A = df_A.to_numpy()
                C = df_C.to_numpy()
                Y = df_Y.to_numpy().T
                Q_train         = df_Q_train.to_numpy()
                R_train         = df_R_train.to_numpy()
                # print(f'det of R_train for comp_{m+1}', np.linalg.det(R_train))

                # if Y.shape[1] != self.total_time: 
                #     raise ValueError(f"Length of time series from config file = {self.total_time} != Length of observation series {Y.shape[1]}")
                
                Y_train         = Y[:,:self.training_time]
                # Y_valid         = Y[:,self.training_time:]

                Y_valid_path    = os.path.join(valid_data_location, f'C{m+1}/y.csv')
                Q_valid_path    = os.path.join(valid_data_location, f'C{m+1}/Q.csv')
                R_valid_path    = os.path.join(valid_data_location, f'C{m+1}/R.csv')

                df_Y_valid      = pd.read_csv(Y_valid_path, header = None)
                df_Q_valid      = pd.read_csv(Q_valid_path, header = None)
                df_R_valid      = pd.read_csv(R_valid_path, header = None)
                Y_valid         = df_Y_valid.to_numpy().T
                Q_valid         = df_Q_valid.to_numpy()
                R_valid         = df_R_valid.to_numpy()
                # print(f'det of R_valid for comp_{m+1}', np.linalg.det(R_valid))
                
                # if Y_valid.shape[1] != self.validation_time: 
                #     raise ValueError(f"Length of time series from config file = {self.validation_time} != Length of observation series {Y_valid.shape[1]}")
                

                d_m, p_m = C.shape

                # print(f'comp_{m+1}, d_m = ', d_m, 'p_m = ', p_m)
                # print(f'comp_{m+1}, R_shape = ', R_train.shape)
                # print(f'comp_{m+1}, Q_shape = ', Q_train.shape)
                # print(f'comp_{m+1}, Y_shape = ', Y_train.shape)
                # print(f'comp_{m+1}, Y_valid shape = ', Y_valid.shape)
                self.comp_size_vec[m, 0]        = p_m
                self.global_state_size          += p_m

                # Taking output size
                self.output_size_vec[m, 0]      = d_m
                self.global_output_size         += d_m

                # Initial values and noise parameters for the local model
                B       = np.zeros((p_m, p_m))
                # Q       = 0.0005 * np.eye(p_m)
                # R       = 0.0005 * np.eye(d_m)
                # P0      = Q
                x0      = np.zeros((p_m, 1))

                self.local_learners_pack[f'comp_{m+1}'] = {

                    'B': B,
                    'Q': Q_train,
                    'R': R_train,
                    'P0': Q_train,
                    'x0': x0,
                    'A': A,
                    'C': C,
                    'Y': Y_train,
                    'd_m': d_m,
                    'p_m': p_m,
                    'eta_l': eta_l[m],
                    'eta_g': eta_g[m],
                    'lambda_l': lambda_l[m],
                }
                self.validation_pack[f'comp_{m+1}']     = {
                    'B': B,
                    'Q': Q_valid,
                    'R': R_valid,
                    'P0': Q_valid,
                    'x0': x0,
                    'A': A,
                    'C': C,
                    'Y': Y_valid,
                    'd_m': d_m,
                    'p_m': p_m,
                    'eta_l': eta_l[m],
                    'eta_g': eta_g[m],
                    'lambda_l': lambda_l[m],
                }
                self.global_Y[f'{m+1}']                 = Y
                self.global_Y_valid[f'{m+1}']           = Y_valid
                A_mm[f'{m+1}{m+1}']                             = A
            
            global_Y                = np.zeros((self.global_output_size, self.total_time))
            global_Y_valid          = np.zeros((self.global_output_size, self. total_time))
            d_start_idx             = 0
            for m in range(self.num_components):
                global_Y[d_start_idx:d_start_idx + self.output_size_vec[m, 0], :] = self.global_Y[f'{m+1}']
                # print(f'comp_{m+1}, reached here')
                # global_Y_valid[d_start_idx:d_start_idx + self.output_size_vec[m, 0], :] = self.global_Y_valid[f'{m+1}']
                if m > 0:
                    self.output_start_vec[m, 0]      = d_start_idx
                    
                d_start_idx         = d_start_idx + self.output_size_vec[m, 0]

            self.global_learners_pack['A_mm']               = A_mm
            self.global_learners_pack['gamma_g']            = self.global_learning_rate
            self.global_learners_pack['lambda_g']           = self.global_regularization_rate

            self.HMatrix_pack['comp_data']                  = self.local_learners_pack
            self.HMatrix_pack['gamma_g']                    = self.global_learning_rate
            self.HMatrix_pack['lambda_g']                   = self.global_regularization_rate
            self.HMatrix_pack['p']                          = self.global_state_size
            self.HMatrix_pack['p_vec']                      = self.comp_size_vec
            self.HMatrix_pack['d']                          = self.global_output_size
            self.HMatrix_pack['d_vec']                      = self.output_size_vec     
            self.HMatrix_pack['M']                          = self.num_components
            self.HMatrix_pack['total_time']                 = self.total_time

            # self.CKF_pack['A_complete']                     = A_comlete
            # self.CKF_pack['C_complete']                     = C_complete
            # self.CKF_pack['Y']                              = global_Y
            # self.CKF_pack['Y_valid']                        = global_Y_valid
            # self.CKF_pack['A_complete_valid']               = A_complete_valid

        except FileNotFoundError as e:
            print(f"An error occurred: {e}")

        except ValueError as e:
            print(f"An error occurred: {e}")








        

