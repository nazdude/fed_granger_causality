This is to try stopping using 'Local Loss'. 

There is no C_complete.valid --> Right now, we are assuming the C matrix remains the same throughout

After SR check, if training is not run, the dictionary to store the data is not created. But the code tries to load this dictionary in every run, so that would cause an error
if a training run was not done before and the dictionary was not previously created. 

