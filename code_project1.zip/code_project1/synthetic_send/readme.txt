There is no C_complete.valid --> Right now, we are assuming the C matrix remains the same throughout

